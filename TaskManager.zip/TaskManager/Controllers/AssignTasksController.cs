﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using TaskManager.BusinessLayer;
using TaskManager.Data;

namespace TaskManager.Controllers
{
    public class AssignTasksController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AssignTasksController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: AssignTasks
        [Authorize]
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.AssignTasks.Include(a => a.Employees).Include(a => a.Tasks);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: AssignTasks/Details/5
        [Authorize]
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var assignTask = await _context.AssignTasks
                .Include(a => a.Employees)
                .Include(a => a.Tasks)
                .FirstOrDefaultAsync(m => m.AssignTaskId == id);
            if (assignTask == null)
            {
                return NotFound();
            }

            return View(assignTask);
        }

        // GET: AssignTasks/Create
        [Authorize]
        public IActionResult Create()
        {
            ViewData["EmployeeId"] = new SelectList(_context.Employees, "Id", "FirstName");
            ViewData["TaskId"] = new SelectList(_context.Tasks, "TaskId", "TaskName");
            return View();
        }

        // POST: AssignTasks/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<IActionResult> Create([Bind("AssignTaskId,EmployeeId,TaskId,Status")] AssignTask assignTask)
        {
            if (ModelState.IsValid)
            {
                _context.Add(assignTask);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["EmployeeId"] = new SelectList(_context.Employees, "Id", "FirstName", assignTask.EmployeeId);
            ViewData["TaskId"] = new SelectList(_context.Tasks, "TaskId", "TaskName", assignTask.TaskId);
            return View(assignTask);
        }

        // GET: AssignTasks/Edit/5
        [Authorize]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var assignTask = await _context.AssignTasks.FindAsync(id);
            if (assignTask == null)
            {
                return NotFound();
            }
            ViewData["EmployeeId"] = new SelectList(_context.Employees, "Id", "FirstName", assignTask.EmployeeId);
            ViewData["TaskId"] = new SelectList(_context.Tasks, "TaskId", "TaskName", assignTask.TaskId);
            return View(assignTask);
        }

        // POST: AssignTasks/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<IActionResult> Edit(int id, [Bind("AssignTaskId,EmployeeId,TaskId,Status")] AssignTask assignTask)
        {
            if (id != assignTask.AssignTaskId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(assignTask);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AssignTaskExists(assignTask.AssignTaskId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["EmployeeId"] = new SelectList(_context.Employees, "Id", "FirstName", assignTask.EmployeeId);
            ViewData["TaskId"] = new SelectList(_context.Tasks, "TaskId", "TaskName", assignTask.TaskId);
            return View(assignTask);
        }

        // GET: AssignTasks/Delete/5
        [Authorize]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var assignTask = await _context.AssignTasks
                .Include(a => a.Employees)
                .Include(a => a.Tasks)
                .FirstOrDefaultAsync(m => m.AssignTaskId == id);
            if (assignTask == null)
            {
                return NotFound();
            }

            return View(assignTask);
        }

        // POST: AssignTasks/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var assignTask = await _context.AssignTasks.FindAsync(id);
            _context.AssignTasks.Remove(assignTask);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AssignTaskExists(int id)
        {
            return _context.AssignTasks.Any(e => e.AssignTaskId == id);
        }
    }
}
