1. Open the Project Solution in Visual Studio
2. Build the project 
3. Click tools and select Nuget Package manager -> Package Manager Console
4. In console execute the command >  update-database
5. After migration is successful Run the project
   Thanks


