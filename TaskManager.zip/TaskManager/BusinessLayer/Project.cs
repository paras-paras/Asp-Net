﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TaskManager.BusinessLayer
{
    public class Project
    {
        [Required]
        public int ProjectId { get; set; }
        [Required]
        public string ProjectTitle { get; set; }
        [Required]
        public string ProjectType { get; set; }
        
        public string Detail { get; set; }

    }
}
