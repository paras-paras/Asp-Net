﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace TaskManager.BusinessLayer
{
    public class Task
    {
        [Key]
        [Required]
        public int TaskId { get; set; }
        
        [Required]
        public int ProjectId { get; set; }

        [Required]
        public string TaskName { get; set; }

        [Required]
        public string TaskDetail { get; set; }

        [ForeignKey("ProjectId")]
        public virtual Project Projects { get; set; }
    }
}
