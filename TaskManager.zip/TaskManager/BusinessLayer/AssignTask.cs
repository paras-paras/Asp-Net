﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace TaskManager.BusinessLayer
{
    public class AssignTask
    {
        [Key]
        [Required]
        public int AssignTaskId { get; set; }

        [Required]
        public int EmployeeId { get; set; }

       
        [Required]
        public int TaskId { get; set; }

        [Required]
        public string Status { get; set; }

        [ForeignKey("EmployeeId")]
        public virtual Employee Employees { get; set; }

       

        [ForeignKey("TaskId")]
        public virtual Task Tasks { get; set; }
    }
}
